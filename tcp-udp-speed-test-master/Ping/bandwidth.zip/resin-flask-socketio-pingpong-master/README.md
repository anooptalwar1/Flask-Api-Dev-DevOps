## A Simple Server with Python Flask

This is a simple Flask-SocketIO server project that works on any of the devices supported by [resin.io][resin-link].

This project simply serves up the Flask-SocketIO sample code on port `:80` of your resin.io device. 

Open up the served web page and you will see a Flask-SocketIO Demonstration allowing you to measure the Ping / Pong latency between your frontend and the backend on your resin.io device.

[resin-link]:https://resin.io/
